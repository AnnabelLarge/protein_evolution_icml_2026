#!/bin/bash

python clean_data.py \
    -pfam_seed_file EXAMPLE_INPUTS/EXAMPLE_Pfam-A.seed \
    -tree_dir EXAMPLE_INPUTS/trees \
    -num_splits 2 \
    -metadata_header header \
    -rand_key 42 \
    -topk1_valid 0 \
    -topk2_valid 0 \
    -alphabet_size 20 \
    -max_len 5000 \
    -batch_size 10
